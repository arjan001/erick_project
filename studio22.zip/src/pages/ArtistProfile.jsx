export { default } from '@/modules/artist/pages/ArtistProfilePage';
