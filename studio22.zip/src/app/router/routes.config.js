import MainLayout from '@/layouts/MainLayout';
import AdminLayout from '@/layouts/AdminLayout';
import DashboardLayout from '@/layouts/DashboardLayout';
import AuthLayout from '@/layouts/AuthLayout';
import { AuthGuard } from '@/app/router/guards/AuthGuard';
import { RoleGuard } from '@/app/router/guards/RoleGuard';
import { GuestGuard } from '@/app/router/guards/GuestGuard';

// Public pages (no auth required)
const publicRoutes = [
  {
    path: '/',
    component: () => import('@/pages/Home'),
    layout: MainLayout,
    exact: true
  },
  {
    path: '/Projects',
    component: () => import('@/modules/projects/pages/ProjectsPage'),
    layout: MainLayout
  },
  {
    path: '/ApplyArtist',
    component: () => import('@/pages/ApplyArtist'),
    layout: MainLayout
  },
  {
    path: '/ApplyTeam',
    component: () => import('@/pages/ApplyTeam'),
    layout: MainLayout
  },
  {
    path: '/ApplyBacker',
    component: () => import('@/pages/ApplyBacker'),
    layout: MainLayout
  },
  {
    path: '/SubmitProject',
    component: () => import('@/pages/SubmitProject'),
    layout: MainLayout
  },
  {
    path: '/BackedProjects',
    component: () => import('@/pages/BackedProjects'),
    layout: MainLayout
  },
  {
    path: '/HowBackingWorks',
    component: () => import('@/pages/HowBackingWorks'),
    layout: MainLayout
  },
  {
    path: '/Services',
    component: () => import('@/pages/Services'),
    layout: MainLayout
  },
  {
    path: '/Work',
    component: () => import('@/pages/Work'),
    layout: MainLayout
  }
];

// Auth pages (guest only - redirect if logged in)
const authRoutes = [
  {
    path: '/SignIn',
    component: () => import('@/pages/SignIn'),
    layout: AuthLayout,
    guard: GuestGuard
  }
];

// Admin routes (admin role only)
const adminRoutes = [
  {
    path: '/Admin',
    component: () => import('@/modules/admin/pages/AdminDashboardPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/ArtistAdmin',
    component: () => import('@/modules/admin/pages/ArtistAdminPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin', 'artist_admin'] })
  },
  {
    path: '/TeamAdmin',
    component: () => import('@/modules/admin/pages/TeamAdminPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin', 'team_admin'] })
  },
  {
    path: '/ProjectAdmin',
    component: () => import('@/modules/admin/pages/ProjectAdminPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin', 'project_admin'] })
  },
  {
    path: '/Admin/UserManagement',
    component: () => import('@/modules/admin/pages/AdminUserManagementPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/RolesPermissions',
    component: () => import('@/modules/admin/pages/AdminRolesPermissionsPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/GeneralSettings',
    component: () => import('@/modules/admin/pages/AdminGeneralSettingsPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/SEOCMS',
    component: () => import('@/modules/admin/pages/AdminSEOCMSPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/ImageStorage',
    component: () => import('@/modules/admin/pages/AdminImageStoragePage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/Invites',
    component: () => import('@/modules/admin/pages/AdminInvitesManagementPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/LoginProviders',
    component: () => import('@/modules/admin/pages/AdminLoginProvidersPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/APISettings',
    component: () => import('@/modules/admin/pages/AdminAPISettingsPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/PaymentSettings',
    component: () => import('@/modules/admin/pages/AdminPaymentSettingsPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/FinanceDashboard',
    component: () => import('@/modules/admin/pages/AdminFinanceDashboardPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/Jobs',
    component: () => import('@/modules/admin/pages/AdminJobsPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/Projects',
    component: () => import('@/modules/admin/pages/AdminProjectsPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/Clients',
    component: () => import('@/modules/admin/pages/AdminClientsPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/Messages',
    component: () => import('@/modules/admin/pages/AdminMessagesPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/Products',
    component: () => import('@/modules/admin/pages/AdminProductsPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/Orders',
    component: () => import('@/modules/admin/pages/AdminOrdersPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/ShopSettings',
    component: () => import('@/modules/admin/pages/AdminShopSettingsPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  },
  {
    path: '/Admin/AuditLogs',
    component: () => import('@/modules/admin/pages/AdminAuditLogsPage'),
    layout: AdminLayout,
    guard: () => RoleGuard({ roles: ['admin'] })
  }
];

// Artist routes (artist role required)
const artistRoutes = [
  {
    path: '/ArtistDashboard',
    component: () => import('@/modules/artist/pages/ArtistDashboardPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['artist', 'artist_admin'] })
  },
  {
    path: '/ArtistProfile',
    component: () => import('@/modules/artist/pages/ArtistProfilePage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['artist', 'artist_admin'] })
  },
  {
    path: '/Jobs',
    component: () => import('@/modules/jobs/pages/JobsPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['artist', 'artist_admin'] })
  },
  {
    path: '/JobApplications',
    component: () => import('@/modules/jobs/pages/JobApplicationsPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['artist', 'artist_admin'] })
  },
  {
    path: '/JobBoard',
    component: () => import('@/modules/jobs/pages/JobBoardPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['artist', 'artist_admin'] })
  },
  {
    path: '/JobInvitations',
    component: () => import('@/modules/jobs/pages/JobInvitationsPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['artist', 'artist_admin'] })
  },
  {
    path: '/Messages',
    component: () => import('@/modules/messages/pages/MessagesPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['artist', 'artist_admin'] })
  },
  {
    path: '/Network',
    component: () => import('@/modules/network/pages/NetworkPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['artist', 'artist_admin'] })
  },
  {
    path: '/Endorsements',
    component: () => import('@/modules/network/pages/EndorsementsPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['artist', 'artist_admin'] })
  },
  {
    path: '/Testimonials',
    component: () => import('@/modules/network/pages/TestimonialsPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['artist', 'artist_admin'] })
  },
  {
    path: '/Notifications',
    component: () => import('@/modules/network/pages/NotificationsPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['artist', 'artist_admin'] })
  },
  {
    path: '/ActivityFeed',
    component: () => import('@/modules/network/pages/ActivityFeedPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['artist', 'artist_admin'] })
  }
];

// Client routes (client role required)
const clientRoutes = [
  {
    path: '/ClientDashboard',
    component: () => import('@/modules/client/pages/ClientDashboardPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['client', 'project_owner'] })
  }
];

// Team routes (team role required)
const teamRoutes = [
  {
    path: '/TeamDashboard',
    component: () => import('@/modules/team/pages/TeamDashboardPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['team', 'team_admin'] })
  }
];

// Backer routes (backer role required)
const backerRoutes = [
  {
    path: '/BackerDashboard',
    component: () => import('@/modules/backer/pages/BackerDashboardPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['backer'] })
  },
  {
    path: '/BackerProfile',
    component: () => import('@/modules/backer/pages/BackerProfilePage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['backer'] })
  },
  {
    path: '/BackerProjects',
    component: () => import('@/modules/backer/pages/BackerProjectsPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['backer'] })
  },
  {
    path: '/BackerInvestments',
    component: () => import('@/modules/backer/pages/BackerInvestmentsPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['backer'] })
  },
  {
    path: '/BackerDeals',
    component: () => import('@/modules/backer/pages/BackerDealsPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['backer'] })
  },
  {
    path: '/BackerAnalytics',
    component: () => import('@/modules/backer/pages/BackerAnalyticsPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['backer'] })
  },
  {
    path: '/BackerBanking',
    component: () => import('@/modules/backer/pages/BackerBankingPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['backer'] })
  },
  {
    path: '/BackerPartners',
    component: () => import('@/modules/backer/pages/BackerPartnersPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['backer'] })
  },
  {
    path: '/BackerInvestmentTiers',
    component: () => import('@/modules/backer/pages/BackerInvestmentTiersPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['backer'] })
  },
  {
    path: '/BackerProjectUpdates',
    component: () => import('@/modules/backer/pages/BackerProjectUpdatesPage'),
    layout: DashboardLayout,
    guard: () => RoleGuard({ roles: ['backer'] })
  }
];

// Protected routes (auth required, no specific role)
const protectedRoutes = [
  {
    path: '/Settings',
    component: () => import('@/pages/Settings'),
    layout: MainLayout,
    guard: AuthGuard
  }
];

// Combine all routes
export const routes = [
  ...publicRoutes,
  ...authRoutes,
  ...adminRoutes,
  ...artistRoutes,
  ...clientRoutes,
  ...teamRoutes,
  ...backerRoutes,
  ...protectedRoutes
];

// Export route groups for easier access
export const routeGroups = {
  public: publicRoutes,
  auth: authRoutes,
  admin: adminRoutes,
  artist: artistRoutes,
  client: clientRoutes,
  team: teamRoutes,
  backer: backerRoutes,
  protected: protectedRoutes
};
