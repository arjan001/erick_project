import { useRole } from '@/modules/auth/hooks/useRole';
import { useNavigate } from 'react-router-dom';

export function RoleGuard({ roles, children }) {
  const { hasRole, isLoading } = useRole();
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!hasRole(roles)) {
    navigate('/');
    return null;
  }

  return children;
}
