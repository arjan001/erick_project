import React from 'react';
import { Outlet } from 'react-router-dom';
import { useRole } from '@/modules/auth/hooks/useRole';
import ArtistSidebar from '@/components/ArtistSidebar';
import BackerSidebar from '@/components/BackerSidebar';

export default function DashboardLayout() {
  const { isArtist, isTeam, isClient, isBacker } = useRole();

  return (
    <div className="min-h-screen bg-white">
      {isArtist && <ArtistSidebar />}
      {isTeam && <ArtistSidebar />}
      {isClient && <ArtistSidebar />}
      {isBacker && <BackerSidebar />}
      <main className={isArtist || isTeam || isClient || isBacker ? 'ml-20' : ''}>
        <Outlet />
      </main>
    </div>
  );
}
