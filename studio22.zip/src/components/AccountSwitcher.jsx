import React, { useState } from 'react';
import { User, LogOut, ChevronDown } from 'lucide-react';
import { createPageUrl } from '@/shared/utils/routing';

const DEMO_ACCOUNTS = [
  { email: 'artist@artist.com', role: 'artist', name: 'Alex Chen' },
  { email: 'team@team.com', role: 'team', name: 'Studio Team' },
  { email: 'client@client.com', role: 'client', name: 'Client User' },
  { email: 'backer@backer.com', role: 'backer', name: 'Investment Group' },
  { email: 'admin@studio22.com', role: 'admin', name: 'Admin User' }
];

export default function AccountSwitcher() {
  const [isOpen, setIsOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState(() => {
    const stored = localStorage.getItem('studio22_user');
    return stored ? JSON.parse(stored) : null;
  });

  const switchAccount = (account) => {
    const user = {
      id: account.email,
      email: account.email,
      full_name: account.name,
      role: account.role
    };
    localStorage.setItem('studio22_user', JSON.stringify(user));
    setCurrentUser(user);
    setIsOpen(false);
    
    // Redirect based on role
    const redirects = {
      artist: '/artistdashboard',
      team: '/teamdashboard',
      client: '/clientdashboard',
      backer: '/backerdashboard',
      admin: '/admin'
    };
    window.location.href = createPageUrl(redirects[account.role]?.replace('/', '') || 'Home');
  };

  const handleLogout = () => {
    localStorage.removeItem('studio22_user');
    window.location.href = createPageUrl('SignIn');
  };

  if (!currentUser) return null;

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
      >
        <User className="w-4 h-4" />
        <span className="text-sm font-medium">{currentUser.full_name}</span>
        <ChevronDown className="w-4 h-4" />
      </button>

      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-xl border border-gray-200 z-50">
            <div className="p-3 border-b border-gray-200">
              <p className="text-xs font-medium text-gray-500">Switch Account</p>
            </div>
            <div className="p-2">
              {DEMO_ACCOUNTS.map((account) => (
                <button
                  key={account.email}
                  onClick={() => switchAccount(account)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                    currentUser.email === account.email
                      ? 'bg-gray-100 text-black'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                    <span className="text-xs font-bold text-gray-600">
                      {account.name.charAt(0)}
                    </span>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{account.name}</p>
                    <p className="text-xs text-gray-500">{account.role}</p>
                  </div>
                  {currentUser.email === account.email && (
                    <span className="text-xs text-green-600">Current</span>
                  )}
                </button>
              ))}
            </div>
            <div className="p-2 border-t border-gray-200">
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-red-600 hover:bg-red-50 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm font-medium">Logout</span>
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
